#include "debug.h"  // CH32V307����ͷ�ļ�

/*/ �������
#define CCD_PIXELS         128     // CCD������
#define ADC_BUFFER_SIZE    CCD_PIXELS
#define FRAME_RATE         25      // ֡��(40ms����=25fps)
#define ARR_TIM2           35      // 2MHz CCDʱ��
#define ARR_TIM3           424     // SH�������+�ӳ�
#define ARR_TIM4           143     // ADC����Ƶ��(144����)
*/
#define CCD_PIXELS         5000     // CCD������
// ȫ�ֱ���
volatile uint8_t frame_ready = 0;  // ֡���ݾ�����־
uint16_t ADC_Value[CCD_PIXELS]; // ADC���ݻ�����
volatile int Period=0;
// TIM2��ʼ��(CCDʱ��)
void getdalay();
void TIM2_CCD_Clock_Init(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // ����GPIO PA0
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);
    
    // ����TIM2ʱ��
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct = {0};
    TIM_TimeBaseInitStruct.TIM_Period = 36-1;
    TIM_TimeBaseInitStruct.TIM_Prescaler = 0;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct);
    
    // ����PWM���
    TIM_OCInitTypeDef TIM_OCInitStruct = {0};
    TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStruct.TIM_Pulse = 18-1;  // 50%ռ�ձ�
    TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM2, &TIM_OCInitStruct);
    TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_Update);
    // ʹ��TIM2
    TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM2, ENABLE);
    TIM_Cmd(TIM2, ENABLE);
}

// TIM3��ʼ��(SH�ź�)
void TIM3_SH_Signal_Init(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // ����GPIO PA6
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);
    
    // ����TIM3ʱ��
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct = {0};
    TIM_TimeBaseInitStruct.TIM_Period = 10-1;
    TIM_TimeBaseInitStruct.TIM_Prescaler = 72-1;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStruct);
    
    // ����PWM���
    TIM_OCInitTypeDef TIM_OCInitStruct = {0};
    TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStruct.TIM_Pulse =5-1;  // 50%ռ�ձ�
    TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM3, &TIM_OCInitStruct);
    
    // ʹ��TIM3
    TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM3, ENABLE);
    TIM_Cmd(TIM3, ENABLE);

}

// TIM1��ʼ��(ICG�ź�)
void TIM1_ICG_Signal_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    
    // ����GPIO PA8
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);
    
    // ����TIM1ʱ��
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct = {0};
    TIM_TimeBaseInitStruct.TIM_Period = 20-1; // 748-1
    TIM_TimeBaseInitStruct.TIM_Prescaler = 72-1;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseInitStruct);
    
    // ����PWM���(������)
    TIM_OCInitTypeDef TIM_OCInitStruct = {0};
    TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM2;
    TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStruct.TIM_Pulse = 10-1; // 100�����ӳ�
    TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High; 
    TIM_OCInitStruct.TIM_OCNPolarity=TIM_OCPolarity_Low;
    TIM_OC1Init(TIM1, &TIM_OCInitStruct);
    
    // ���õ�����ģʽ
    TIM_SelectOnePulseMode(TIM1, TIM_OPMode_Single);
    
    // ʹ��TIM1
    TIM_CtrlPWMOutputs(TIM1, ENABLE);
    TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM1, ENABLE);
}


// ADC����(��DMA)
s16 Calibrattion_Val = 0;
uint16_t TxBuf[CCD_PIXELS];
void ADC_Function_Init(void)
{
    ADC_InitTypeDef ADC_InitStructure = {0};
    DMA_InitTypeDef DMA_InitStructure = {0};
    GPIO_InitTypeDef GPIO_InitStructure={0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE );

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T4_CC4;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);//1

    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_1Cycles5);
    
    ADC_Cmd(ADC1, ENABLE);
    
    ADC_BufferCmd(ADC1, DISABLE); //disable buffer
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));
    Calibrattion_Val = Get_CalibrationValue(ADC1);
    ADC_ExternalTrigConvCmd(ADC1, ENABLE);

    ADC_DMACmd(ADC1, ENABLE);

    DMA_DeInit(DMA1_Channel1);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->RDATAR;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)TxBuf; 
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
    DMA_InitStructure.DMA_BufferSize = CCD_PIXELS; 
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);

    DMA_Cmd(DMA1_Channel1, ENABLE);

    DMA_ITConfig(DMA1_Channel1, DMA_IT_TC, ENABLE);

    TIM_OCInitTypeDef       TIM_OCInitStructure = {0};
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure = {0};

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    TIM_TimeBaseInitStructure.TIM_Period = 144 - 1;
    TIM_TimeBaseInitStructure.TIM_Prescaler = 0;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);
    TIM_SelectSlaveMode(TIM4, TIM_SlaveMode_Trigger);
    TIM_SelectMasterSlaveMode(TIM4, TIM_MasterSlaveMode_Enable);
    TIM_SelectInputTrigger(TIM4, TIM_TS_ITR1);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 72 - 1;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC4Init(TIM4, &TIM_OCInitStructure);
    TIM_SelectOutputTrigger(TIM4, TIM_TRGOSource_Update);
    
    TIM_SetCounter(TIM4, 2); 
    TIM_CtrlPWMOutputs(TIM4, ENABLE);
    TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Disable);
    TIM_ARRPreloadConfig(TIM4, ENABLE);

    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = DMA1_Channel1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

// USART��ʼ��(�������)
void USART2_Init(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE); 

    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    
    
    USART_InitStructure.USART_BaudRate = 921600;                
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;     
    USART_InitStructure.USART_Parity = USART_Parity_No;        
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;      
    USART_Init(USART2, &USART_InitStructure);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART2, ENABLE);
}
void calculationtim3();
uint8_t sendflag=0;
volatile uint8_t s;
void USART2_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void USART2_IRQHandler(void) {
    if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        uint8_t received_data = USART_ReceiveData(USART2);
        if (received_data==0xA1) {
            sendflag=1;
        }
        else {
            s=received_data;
            getdalay();
            calculationtim3();
        }
    }
}
// ��������: �����ַ�
void USART_SendChar(USART_TypeDef* USARTx, uint8_t ch)
{
    while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);
    USART_SendData(USARTx, ch);
}

// ��������: �����ַ���
void USART_SendString(USART_TypeDef* USARTx, char* str)
{
    while(*str){
        USART_SendChar(USARTx, *str++);
    }
}

// ��������: ����16λ����ֵ
void USART_SendInt(USART_TypeDef* USARTx, uint16_t value)
{
    char buffer[6];
    sprintf(buffer, "%5u", value);
    USART_SendString(USARTx, buffer);
}
u16 Get_ConversionVal(s16 val)
{
    if((val+Calibrattion_Val)<0|| val==0) return 0;
    if((Calibrattion_Val+val)>4095||val==4095) return 4095;
    return (val+Calibrattion_Val);
}
volatile int t=7500;
volatile int si=15;
volatile int xi=15;
void calculationtim3(void)//us
{
    int Period;
    Period=t;
    TIM3->ATRLR=Period-1;
    TIM3->CH1CVR=Period*0.5;
    TIM1->ATRLR=2*(Period+10)-1;
    TIM1->CH1CVR=(Period+10)*1.5;
}
/*void getdalay(void)
{

    switch(s) {
        case 0xB1: t = 10;  xi = 43; si=6; break;  // 10��s
        case 0xB2: t = 20;  xi = 43;si=6;  break;  // 20��s
        case 0xB3: t = 50;  xi = 43; si=27; break;  // 50��s
        case 0xB4: t = 60;  xi = 43; si=27; break;  // 60��s
        case 0xB5: t = 75;  xi = 43; si=27; break;  // 75��s
        case 0xB6: t = 100; xi = 43; si=27;break;  // 100��s
        case 0xB7: t = 500; xi = 43; si=27;break;  // 500��s
        case 0xB8: t = 1250; xi = 43;si=26; break;  // 1.25ms
        case 0xB9: t = 2500; xi = 43;si=26; break;  // 2.5ms
        case 0xBA: t = 7500; xi = 43; si=26;break;  // 7.5ms
        default:   t = 10;   xi = 43; si=6;  break;
    }

}*/
void getdalay(void)
{

    switch(s) {
        case 0xB1: t = 10;  xi = 43; si=16; break;  // 10��s
        case 0xB2: t = 20;  xi = 43;si=16;  break;  // 20��s
        case 0xB3: t = 50;  xi = 43; si=16; break;  // 50��s
        case 0xB4: t = 60;  xi = 43; si=16; break;  // 60��s
        case 0xB5: t = 75;  xi = 43; si=16; break;  // 75��s
        case 0xB6: t = 100; xi = 43; si=16;break;  // 100��s
        case 0xB7: t = 500; xi = 43; si=16;break;  // 500��s
        case 0xB8: t = 1250; xi = 43;si=16; break;  // 1.25ms
        case 0xB9: t = 2500; xi = 43;si=16; break;  // 2.5ms
        case 0xBA: t = 7500; xi = 43; si=16;break;  // 7.5ms
        default:   t = 10;   xi = 43; si=16;  break;
    }

}
// ���CCD����(�ı���ʽ)
uint16_t TxBuf[CCD_PIXELS];
void Output_CCD_Data(void)
{
    int delayt=xi;
    for(int i = delayt; i < delayt+3648; i++)
    {
        uint16_t value = Get_ConversionVal(TxBuf[i]);
        // ���͵��ֽ�
        USART_SendData(USART2, value & 0xFF);
       
        // �ȴ��������
        while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
         // ���͸��ֽ�
        USART_SendData(USART2, (value >> 8) & 0xFF);
        // �ȴ��������
        while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
    }
 /*  USART_SendString(USART2, "\r\n---------------------\r\n");
    for(int i = 0; i < 5000; i++)//88 3736
    {
        USART_SendInt(USART2, Get_ConversionVal(TxBuf[i]));
        
        // ÿ8�����ݻ���
        if((i+1) % 8 == 0) USART_SendString(USART2, "\r\n");
        else USART_SendString(USART2, " ");

    }
    USART_SendString(USART2, "\r\n---------------------\r\n");*/

}

// DMA�жϴ���(֡���ݾ���)
// DMA�жϴ���(֡���ݾ���)
void DMA1_Channel1_IRQHandler(void) __attribute__((interrupt("WCH-Interrupt-fast")));
void DMA1_Channel1_IRQHandler(void)
{
    if(DMA_GetITStatus(DMA1_IT_TC1))
    {
        // �������DMA�жϱ�־
        DMA_ClearITPendingBit(DMA1_IT_GL1 | DMA1_IT_TC1 | DMA1_IT_HT1 | DMA1_IT_TE1);
        
        // ����DMAͨ��
        DMA_Cmd(DMA1_Channel1, DISABLE);
        
        // ����DMA���������
        DMA_SetCurrDataCounter(DMA1_Channel1, CCD_PIXELS);
        
        // ��������DMAͨ��
        DMA_Cmd(DMA1_Channel1, ENABLE);
        ADC_Cmd(ADC1, DISABLE);         // �ر�ADC

        // ����֡���ݾ�����־
        frame_ready = 1;
    }
}

// ������
int main(void)
{
    // ϵͳ��ʼ��
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    SystemCoreClockUpdate();
    Delay_Init();
    // �����ʼ��
    USART2_Init();               // USART�����������
    TIM2_CCD_Clock_Init();       // CCDʱ���ź�
    TIM1_ICG_Signal_Init();      // ICG�ź�
    TIM3_SH_Signal_Init();       // SH�ź�
    ADC_Function_Init();            // ADC�ɼ�����
    // �ȴ�ADC�ȶ�
    Delay_Ms(5);

    TIM_Cmd(TIM3, ENABLE);
    // �����������ж�ʱ��
    TIM_Cmd(TIM2, ENABLE);  // CCDʱ��
    Delay_Ms(5);
    TIM2->CNT = 0; 
    TIM4->CNT = 0; 
    
    s =0xBA;
    getdalay();
    calculationtim3();
    int ti=0;
    while(1)
    {   

            
         /*  
            TIM1->CNT = 0;
            TIM1->CTLR1 |= TIM_CEN;
            TIM3->CNT = t-7;
            ADC_Cmd(ADC1, ENABLE);
            while(frame_ready == 0);
    
    
        if (sendflag==1&&frame_ready == 1) {
        
            sendflag=0;
            // �������������
            Output_CCD_Data();

            }
            Delay_Ms(10+0.002*t); 
            frame_ready = 0;*/
            
            if (ti==3) {
                if (sendflag==1) {
                
                sendflag=0;
                TIM_Cmd(TIM3, DISABLE);
                TIM_Cmd(TIM1, DISABLE);
            while(frame_ready == 0);
            frame_ready = 0;
            
            // �������������
            Output_CCD_Data();
            TIM_Cmd(TIM3, ENABLE);
            TIM_Cmd(TIM1, ENABLE);
            Delay_Ms(30);}ti=0;
            }
            else {
            TIM1->CNT = 0;
            TIM1->CTLR1 |= TIM_CEN;
            TIM3->CNT = t-16;
            Delay_Us(2*t);
            ADC_Cmd(ADC1, ENABLE);
            ti=ti+1;
            Delay_Ms(20);
            }
    }

}






