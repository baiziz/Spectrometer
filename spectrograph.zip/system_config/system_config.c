#include "system_config.h"


uint8_t data_buffer[DATA_BUFFER_SIZE] = {0};
int16_t data_temp[TEMP_DATA_SIZE] = {0};
uint8_t data_back[BACK_SIZE] = {0};
uint8_t data_true[920] = {0};
uint8_t data_true1[920] = {0};
uint8_t data_basic[920] = {0};
uint32_t sysTickCnt = 0;
uint16_t data_buffer_index = 0;
uint8_t adc_resolution = 0;
uint32_t auto_collect_interval = 10000;
uint8_t auto_collect_enabled = 0;
uint8_t Serial_RxFlag = 0;
uint8_t Average_Flag = 1;
uint8_t time_set = 0;
uint8_t adjust_flag = 0;
uint8_t resolusion_flag=0;
uint8_t basic_collect = 1;
uint8_t delete_flag = 0;
uint8_t sava_flag = 0;
uint8_t reset_flag = 0;
uint16_t tmp[TEMP_DATA_SIZE]={0}; 
float resolusions=0;
float Ax = 0.1875;
float Bx = 430.0;
float ax = 0.1875;
float bx = 430.0;