#ifndef __USART_H
#define __USART_H

#include "system_config.h"

void My_USART2_Init(void);
void My_USART3_Init(void);
void Serial_SendByte3(uint8_t Byte);
void Serial_SendByte2(uint8_t Byte);
void Serial_SendString(char *str);
uint8_t Serial_GetRxFlag(void);
void TIM6_Init(void);
uint32_t GetSystemTick(void);

#endif