#include "command.h"
#include "usart.h"
#include <math.h>

void change_data() {
    float adjust_data[8];
    if(data_back[0] == 0x01) {
        adjust_flag=1;
        float x[4];
        for(uint8_t i=0x01;i<5;i++) {   
            adjust_data[i-1]=(data_back[2*i]*256+data_back[2*i-1])*0.1;
            x[i-1]=(adjust_data[i-1]-Bx)/Ax;
        }
        ax=(fabs(x[3]-x[2])/fabs(x[1]-x[0]))*Ax;
        bx=adjust_data[2]-ax*x[0];
    }
    auto_collect_enabled=data_back[9];
    auto_collect_interval=(data_back[11]*256+data_back[10])*1000;
    Average_Flag=data_back[12];
    time_set=data_back[13];
    basic_collect=data_back[14];
    delete_flag=data_back[15];
    reset_flag=data_back[16];
    sava_flag=data_back[17];
    resolusion_flag=data_back[18];
}

void SendStartCommand(void) {
    uint8_t command;
    
    if(adc_resolution == 0) command = 0xA1;
    else if(adc_resolution == 1) command = 0xA2;
    else command = 0xA3;
    
    Serial_SendByte3(command);
    data_buffer_index = 0; // ��ջ�����
}

void SetIntegrationTime(uint8_t time_setting) {
    uint8_t command;
    
    switch(time_setting) {
        case 0: command = 0xB1; break;  // 10��s
        case 1: command = 0xB2; break;  // 20��s
        case 2: command = 0xB3; break;  // 50��s
        case 3: command = 0xB4; break;  // 60��s
        case 4: command = 0xB5; break;  // 75��s
        case 5: command = 0xB6; break;  // 100��s
        case 6: command = 0xB7; break;  // 500��s
        case 7: command = 0xB8; break;  // 1.25ms
        case 8: command = 0xB9; break;  // 2.5ms
        case 9: command = 0xBA; break;  // 7.5ms
        default: command = 0xB1; break;
    }
    Serial_SendByte3(command);
    data_buffer_index = 0; // ��ջ�����
}

void SaveDataToFile(void) {
    for(uint16_t i = 0; i < 3648; i++) { 
        char buf[20];
        sprintf(buf, "%d: %d\r\n", i, data_temp[i]);
        Serial_SendString(buf);
    }
}