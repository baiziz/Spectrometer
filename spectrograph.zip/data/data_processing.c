#include "data_processing.h"
#include "usart.h"

void ProcessReceivedData(void) {
    if(data_buffer_index == 0) return;
    
    if(adc_resolution == 0) { 
        if(data_buffer_index >= 7296) {
            for(uint16_t i = 0; i < 3648; i++) {
                data_temp[i] = 4700 - 1.5*(data_buffer[2*i+1] * 256 + data_buffer[2*i]);
            }
            data_buffer_index = 0;
        }
    }
}

void ProcessReceivedData1() {    //��һ���ӿ�
    uint16_t a=0;
    for(uint16_t i = 0; i < 900; i++) {
        if(a<data_true[i]){a=data_true[i];};
    }
    if(a>0x15){
        a=0xFD/a;
        for(uint16_t i = 0; i < 900; i++) {
            data_true[i]=data_true[i]*a;
        }
    }
}

void ProcessReceivedData2() {   
    int i0;
    float i1;
    int band=(ax*912+bx-Bx)/Ax;
    
    if(reset_flag==1) {     //����У׼
        ax=0.1875;
        bx=430;
        adjust_flag=0;
        reset_flag=0;
    }
    
    if(adjust_flag==1) {     //����У׼����
        for(uint16_t i = band; i >0; i--) {
            i1=(Ax*i+Bx-bx)/ax;
            if(i1>0){i0=i1;
            data_true1[i]=data_true[i0]+(i1-i0)*(data_true[i0+1]-data_true[i0]);}
            else {
            data_true1[i]=0X05;
            }
        }
    }
    
    if(basic_collect==1) {   //�ɼ�����
        for(uint16_t i = 0; i < band; i++) {
            data_basic[i]=data_true1[i];
        }
        basic_collect=0;
    }
    
    if(delete_flag==1) {    //ȥ������
        for(uint16_t i = 0; i < band; i++) {
            if (data_true1[i]-data_basic[i]>0&&data_true1[i]-data_basic[i]+20<0xFF) {
                data_true1[i]=data_true1[i]-data_basic[i]+20;
            }
            else if (data_true1[i]-data_basic[i]+20>0xFF) {
                data_true1[i]=0xfd;
            }
            else {
                data_true1[i]=20;
            }
        }
        delete_flag=0;
    }
    
    if (sava_flag==1) {
        // �������ݲ���
    }
    for(uint16_t i = band; i >0; i--){if(data_true1[i]>=0xFE){data_true1[i]=0xFD;}}
}
void ProcessReceivedData3(void){
    for(uint16_t i = 0; i < 3648; i++){tmp[i]= tmp[i]/10;}
    if (resolusion_flag==1) {
        for(uint16_t i = 0; i < 912; i++){
		tmp[i]=tmp[i+2700]/Average_Flag;
        tmp[i]=tmp[i]+20;
        if(tmp[i]>=0xFE){tmp[i]=0xFD;}
        data_true[i]=tmp[i];
        data_true1[i]=data_true[i];}
	}
    else {
        for(uint16_t i = 0; i < 912; i++){
		tmp[i]=(tmp[4*i]+tmp[4*i+1]+tmp[4*i+2]+tmp[4*i+3])/4/Average_Flag;
        tmp[i]=tmp[i]+20;
        if(tmp[i]>=0xFE){tmp[i]=0xFD;}
        data_true[i]=tmp[i];
        data_true1[i]=data_true[i];
	}}
    for(uint16_t i = 0; i < 3648; i++) {tmp[i]=0;}
                    
}
void Senddata(void) {          //
    int band=(ax*912+bx-Bx)/Ax;
    
    Serial_SendByte2(0xFE);
    for(uint16_t i = band; i >0; i--) {
        Serial_SendByte2(data_true1[i]);
    }
    Serial_SendByte2(0xFF);
}