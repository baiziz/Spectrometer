#ifndef __COMMAND_H
#define __COMMAND_H

#include "system_config.h"

void change_data(void);
void SendStartCommand(void);
void SetIntegrationTime(uint8_t time_setting);
void SaveDataToFile(void);

#endif