#ifndef __DATA_PROCESSING_H
#define __DATA_PROCESSING_H

#include "system_config.h"

void ProcessReceivedData(void);
void ProcessReceivedData1(void);
void ProcessReceivedData2(void);
void ProcessReceivedData3(void);
void Senddata(void);

#endif