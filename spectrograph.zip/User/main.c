#include "system_config.h"
#include "usart.h"
#include "data_processing.h"
#include "command.h"

int main(void) {
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    SystemCoreClockUpdate();
    Delay_Init();

    My_USART2_Init();
    My_USART3_Init();
    TIM6_Init();  

    adc_resolution = 0; // Ĭ�ϲɼ�ģʽ12λAD
    SetIntegrationTime(0); // Ĭ�ϻ���ʱ��10��s
    SystemState state = STATE_IDLE;
    uint32_t last_state_time = GetSystemTick();
    uint32_t timeout = 10000; // 10ms
	uint8_t Ave = 0;
    data_back[0]=0;data_back[1]=0x32;data_back[2]=0;data_back[3]=1;data_back[4]=0; //Ĭ��ָ������

	
    while(1) {
        uint32_t current_time = GetSystemTick();
        
        switch(state) {
            case STATE_IDLE:
              	if(auto_collect_enabled==0x01 && (current_time - last_state_time > auto_collect_interval)) {

                	state = STATE_START_COLLECT;
                }
				else if(Serial_GetRxFlag()){
					change_data();
					state = STATE_START_COLLECT;
			    }
            	break;
                
            case STATE_START_COLLECT:
				SetIntegrationTime(time_set);
                SendStartCommand();
                state = STATE_WAIT_DATA;
                last_state_time = current_time;
                timeout = 20000; 
                break;
                
            case STATE_WAIT_DATA:
                if(adc_resolution == 0 && data_buffer_index >= 7296) {
                    state = STATE_PROCESS_DATA;
                }
                else if(current_time - last_state_time >= timeout) {
                    state = STATE_START_COLLECT; // ����
                }
                break;
                
            case STATE_PROCESS_DATA:
                ProcessReceivedData(); 
                state = STATE_AVERAGE_DATA;
                Senddata();
                break;

			case STATE_AVERAGE_DATA:
                 if(Ave < Average_Flag){
					for(uint16_t i = 0; i < 3648; i++){
						tmp[i] = data_temp[i]+tmp[i];
					}
					Ave++;
					state = STATE_START_COLLECT;
                    Delay_Ms(20);
				 }
				 if(Ave>=Average_Flag){
					ProcessReceivedData3();
					Ave = 0;
					state = STATE_SAVE_DATA;
				 }
                
                break;

            case STATE_SAVE_DATA:
                ProcessReceivedData2();
                state = STATE_IDLE;

                last_state_time = current_time;
                break;
        }
    }
    Delay_Ms(10000);
}